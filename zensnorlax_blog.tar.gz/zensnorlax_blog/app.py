from init_db import db ,app

@app.route("/")
def index():
    return "Hello World!"

@app.route("/1")
def post1():
    return "Hello World!"