from models import db, Post
from flask import Flask
import json

app = Flask(__name__)
# 数据库配置
db_uri = "sqlite:///database.db"
app.config["SQLALCHEMY_DATABASE_URI"] = db_uri
app.config["SQLALCHEMY_TRACK_MODIFICATIONS"] = False
db.init_app(app)
with app.app_context():
    db.create_all()
    # 导入instance中的数据
    with open("instance/import_db.json") as f:
        data = json.load(f)
        for item in data:
            post = Post(
                title=item["title"],
                content_path=item["content_path"],
                created=item["created"],
            )
            # 检测数据库中是否已经有这个数据
            if db.session.query(Post).filter_by(title=post.title).count() == 0:
                db.session.add(post)
                db.session.commit()
        # 打印数据库中的数据
        for post in Post.query.all():
            print(post.title)
            print(post.content_path)
            print(post.created)
